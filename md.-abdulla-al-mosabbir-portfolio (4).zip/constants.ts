
import type { PortfolioData, NavLink } from './types';

export const portfolioData: PortfolioData = {
  name: "MD. Abdulla Al Mosabbir",
  title: "Jr. System Engineer",
  tagline: "Specializing in Cloud Infrastructure, Enterprise Networking, and System Administration with 3+ years of technical expertise.",
  about: "System Engineer with 3+ years of experience in enterprise IT operations, Windows Server, Linux, Microsoft 365, and Microsoft Azure. Skilled in deploying secure infrastructure, managing networks, and maintaining high availability systems with strong documentation and troubleshooting expertise. Currently pursuing a BSC in Computer Science & Engineering at Dhaka International University.",
  skills: [
    {
      name: "Cloud & Microsoft",
      items: ["Microsoft Azure (VM, VNet, RBAC)", "Azure Monitor & Identity", "Microsoft 365 Administration", "Exchange, Teams, SharePoint"],
    },
    {
      name: "Networking",
      items: ["MikroTik RouterOS", "VLAN, Firewall, QoS", "VPN (WireGuard, L2TP, EoIP)", "LAN/WAN Design & Troubleshooting", "Zabbix Monitoring"],
    },
    {
      name: "System & Server",
      items: ["Windows Server 2016/2022", "Linux (RHEL, CentOS, Ubuntu)", "Active Directory & File Server", "VMware, Backup & DR (Veeam)", "Namecheap, cPanel, & WHM"],
    },
  ],
  experience: [

     {
      title: "Microsoft Student Ambassador",
      company: "MICROSOFT",
      duration: "Jan 2026 – Running..",
      responsibilities: [
        "Empower fellow students to build technology skills through workshops and mentorship.",
        "Facilitate peer-to-peer learning on Microsoft Azure, M365, and AI technologies.",
        "Organize and host technical events to promote Microsoft learning paths and certifications.",
        "Collaborate with a global community of student leaders to drive innovation and digital literacy."
      ],
      link: "https://mvp.microsoft.com/en-US/studentambassadors/profile/aefcba82-35c3-4902-a677-ec4ac9c1daae",
    },
    {
      title: "IT ENGINEER",
      company: "BG GROUP",
      duration: "Feb 2024 – Present",
      responsibilities: [
        "Provide end-user IT support, troubleshooting, and system maintenance.",
        "Install, configure & maintain CCTV/IP surveillance systems for security operations.",
        "Manage Enterprise Email systems (Microsoft 365, Zimbra, Google Workspace).",
        "Monitor company hosting infrastructure via Namecheap cPanel/WHM to ensure uptime.",
        "Configure and maintain MikroTik routers, switches, VLANs, and firewall rules.",
        "Establish secure VPN tunnels (WireGuard, EoIP, L2TP) between remote locations.",
      ],
    },
    {
      title: "Jr.System Engineer (IT & MIS)",
      company: "Ibrahim Cardiac Hospital & Research Institute",
      duration: "Jan 2023 – Feb 2024",
      responsibilities: [
        "Supported MIS software, printers, attendance systems & hospital IT devices.",
        "Provided Microsoft 365 support for mailbox, password reset & device login.",
        "Ensured uptime of hospital IT infrastructure and maintained documentation.",
      ],
    },
  ],
  education: [
    {
      degree: "BSC in Computer Science & Engineering",
      institution: "Dhaka International University",
      status: "Running",
    },
    {
      degree: "Diploma in Computer Engineering",
      institution: "Kurigram Polytechnic Institute",
      year: "2023",
    },
  ],
  certifications: [
    {
      title: "Microsoft Certified: Azure Administrator Associate (AZ-104)",
      provider: "Microsoft",
      details: "Credential ID: 6416F7D4F6E161FE. Expert in Azure Identity, VNet, Security, and Compute.",
      link: "https://learn.microsoft.com/api/credentials/share/en-us/MosabbirMridu/6416F7D4F6E161FE?sharingId=studentamb_490811",
    },
    {
      title: "Administrator Expert (MS-102)",
      provider: "Microsoft 365",
      details: "Certified in Security & Compliance, Data Loss Prevention, and Message Trace troubleshooting.",
    },
    {
      title: "SERVER ADMINISTRATION",
      provider: "MWINDOWS,LINUX",
      details: "Server Administartion",
    },
    {
      title: "CCNA (201-301)",
      provider: "Cisco",
      details: "Routing protocols, VLAN, STP, RSTP, VPN, and Network Redundancy.",
    },
    {
      title: "MTCNA & MTCRE",
      provider: "MikroTik",
      details: "Certified Network Associate and Routing Engineer.",
    },
  ],
  projects: [
    {
      name: "Azure Enterprise Server: Secure Multi-Service Stack with Zero-Trust Architecture",
      description: "A high-performance hosting environment using Azure VMs, Cloudflare Zero Trust Tunnels, and CyberPanel for secure, origin-hidden web deployments.",
      github: "https://github.com/mosabbir4210/Azure-Enterprise-Server-Secure-Multi-Service-Stack-with-Zero-Trust-Architecture",
      link: "/infrastructure.html",
      tags: ["Azure VM", "Cloudflare", "CyberPanel", "Security"]
    },
    {
      name: "Attendance Device Integration System",
      description: "Implemented full deployment on Azure VM using Ubuntu, Nginx, Laravel, and MySQL for ZKTeco MB460 attendance devices.",
      github: "https://github.com/mosabbir4210/Attendance-Cloud-Project",
      tags: ["Azure", "Ubuntu", "Laravel", "MySQL"]
    },
    {
      name: "Enterprise Network Deployment",
      description: "Designed multi-building network infrastructure including MikroTik routing, VLAN segmentation, and VPN tunnels (WireGuard/L2TP).",
      tags: ["Cisco", "Mikrotik", "Networking"]
    },
    {
      name: "Linux Hosting Server Setup",
      description: "Production-ready Linux web stack featuring performance-tuned Nginx, PHP-FPM, and automated SSL lifecycle management.",
      github:"https://github.com/mosabbir4210/AZURE-Cyberpanel_Deployment",
      tags: ["Linux", "Nginx", "SSL", "DevOps"]
    },
  ],
  contact: {
    email: "mosabbirmridu@outlook.com",
    phone: "01781090468",
    address: "615/3 Shewrapara, Mirpur-10, Dhaka",
    linkedin: "https://linkedin.com/in/mosabbirmridu",
    github: "https://github.com/mosabbir4210"
  }
};

export const navLinks: NavLink[] = [
  { href: "#hero", text: "Home" },
  { href: "#about", text: "About" },
  { href: "#skills", text: "Skills" },
  { href: "#experience", text: "Experience" },
  { href: "#certifications", text: "Certifications" },
  { href: "#projects", text: "Projects" },
];
