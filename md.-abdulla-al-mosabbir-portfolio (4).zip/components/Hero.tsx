
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Shield, Globe, Activity, FileText, Cloud, Database, Cpu } from 'lucide-react';
import type { PortfolioData } from '../types';

interface HeroProps {
  data: Pick<PortfolioData, 'name' | 'title' | 'tagline'>;
}

const TypewriterText: React.FC<{ text: string; delay?: number; className?: string }> = ({ text, delay = 0, className }) => {
  const [index, setIndex] = useState(0);
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      let i = 0;
      const interval = setInterval(() => {
        setIndex(prev => {
          if (prev >= text.length) {
            clearInterval(interval);
            return prev;
          }
          return prev + 1;
        });
      }, 30);
      return () => clearInterval(interval);
    }, delay);
    return () => clearTimeout(timeout);
  }, [text, delay]);

  return (
    <span className={className}>
      {text.split('').map((char, i) => (
        <span key={i} className={i < index ? 'opacity-100 text-inherit' : 'opacity-0 text-transparent'}>
          {char}
        </span>
      ))}
      {index < text.length && (
        <motion.span
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 0.8, repeat: Infinity }}
          className="inline-block w-[3px] h-[0.8em] bg-brand-primary ml-1 align-middle animate-pulse"
        />
      )}
    </span>
  );
};

const ParticleBackground = () => {
  const particles = useMemo(() => Array.from({ length: 20 }), []);
  
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-brand-primary/20 rounded-full"
          initial={{ 
            x: Math.random() * 100 + "%", 
            y: Math.random() * 100 + "%",
            opacity: Math.random() * 0.5
          }}
          animate={{
            y: ["0%", "100%"],
            opacity: [0, 0.4, 0],
            scale: [1, 1.5, 1]
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            ease: "linear",
            delay: Math.random() * 10
          }}
        />
      ))}
    </div>
  );
};

const Hero: React.FC<HeroProps> = ({ data }) => {
  const [systemLoad, setSystemLoad] = useState(65);
  const [uptime, setUptime] = useState(99.98);

  // Fluctuating values for "live" feel
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemLoad(prev => Math.min(95, Math.max(40, prev + (Math.random() * 10 - 5))));
      setUptime(prev => Math.min(100, Math.max(99.9, prev + (Math.random() * 0.01 - 0.005))));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-slate-950">
      <ParticleBackground />
      {/* Matrix-like grid effect */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20"></div>
      
      {/* Background visual elements */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-primary/10 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-cyan-500/10 blur-[120px] rounded-full"></div>
      
      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="flex items-center gap-2 mb-6">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-primary"></span>
            </span>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-brand-primary">root@portfolio:~$ uptime --status</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight tracking-tight">
            <TypewriterText text={data.name} />
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-lg leading-relaxed relative min-h-[3.5em]">
            <span className="text-brand-primary font-mono select-none">{"> "}</span>
            <TypewriterText text={data.tagline} delay={1200} />
          </p>
          
          <div className="flex flex-wrap gap-4 items-center">
            <motion.a
              href="#contact"
              className="px-8 py-4 bg-brand-primary text-slate-950 font-bold rounded-lg hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all duration-300 flex items-center gap-2"
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
            >
              INITIALIZE_CONNECTION
            </motion.a>
            <motion.a
              href="/resume.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 border border-brand-primary/30 text-brand-primary font-medium rounded-lg hover:bg-brand-primary/10 transition-all duration-300 flex items-center gap-2"
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
            >
              <FileText size={18} />
              PREVIEW_RESUME
            </motion.a>
          </div>

          <div className="mt-12 flex gap-6 opacity-60 hover:opacity-100 transition-opacity">
            <div className="flex items-center gap-2 text-slate-300 hover:text-brand-primary transition-colors cursor-default">
              <Cloud size={16} /> <span className="font-mono text-xs uppercase font-bold">Azure</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300 hover:text-brand-primary transition-colors cursor-default">
              <Cpu size={16} /> <span className="font-mono text-xs uppercase font-bold">Linux</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300 hover:text-brand-primary transition-colors cursor-default">
              <Database size={16} /> <span className="font-mono text-xs uppercase font-bold">System_Admin</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 0.95, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative hidden lg:block"
        >
          <div className="glass-card p-4 relative group overflow-hidden border-brand-primary/20 bg-slate-900/80 backdrop-blur-xl">
            <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/10 via-transparent to-transparent opacity-50 group-hover:opacity-100 transition-opacity"></div>
            
            {/* Terminal Top Bar */}
            <div className="flex items-center justify-between mb-6 border-b border-slate-800/50 pb-3">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/30"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/30"></div>
                <div className="w-3 h-3 rounded-full bg-brand-primary/30"></div>
              </div>
              <div className="font-mono text-[10px] text-brand-primary flex items-center gap-2">
                <Activity size={10} className="animate-pulse" />
                INFRA_MONITOR_v4.2 // STATUS: EXCELLENT
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6 relative z-10">
              <div className="space-y-6">
                <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 shadow-inner group/node">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-brand-primary">
                      <Cpu className="w-4 h-4" />
                      <span className="font-mono text-[10px] font-bold uppercase tracking-wider">System Load</span>
                    </div>
                    <span className="font-mono text-[10px] text-slate-500">{Math.round(systemLoad)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-brand-primary shadow-[0_0_10px_#10b981]"
                      animate={{ width: `${systemLoad}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>

                <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 shadow-inner">
                  <div className="flex items-center gap-2 mb-3 text-cyan-400">
                    <Globe className="w-4 h-4" />
                    <span className="font-mono text-[10px] font-bold uppercase tracking-wider">Node Status</span>
                  </div>
                  <div className="flex gap-1.5">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0.3 }}
                        animate={{ opacity: i < 7 ? [0.3, 1, 0.3] : 0.1 }}
                        transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
                        className={`h-6 w-1.5 rounded-full ${i < 7 ? "bg-cyan-500 shadow-[0_0_8px_#06b6d4]" : "bg-slate-800"}`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 shadow-inner flex flex-col h-full relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-400/5 blur-2xl rounded-full"></div>
                <div className="flex items-center gap-2 mb-4 text-emerald-400">
                  <Shield className="w-4 h-4" />
                  <span className="font-mono text-[10px] font-bold uppercase tracking-wider">Security Protocol</span>
                </div>
                <div className="font-mono text-[11px] space-y-3 relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 tracking-tighter">{"> SSL_CERT:"}</span>
                    <span className="text-emerald-500 font-bold">ACTIVE</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 tracking-tighter">{"> FIREWALL:"}</span>
                    <span className="text-emerald-500 font-bold animate-pulse">UP</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 tracking-tighter">{"> THREATS:"}</span>
                    <span className="text-brand-primary font-bold">0_DETECTED</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-slate-950/80 rounded-xl border border-slate-800 shadow-inner font-mono text-[10px]">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-brand-primary animate-pulse shadow-[0_0_5px_#10b981]"></div>
                  <span className="text-slate-300 font-bold">Azure_Instance_01</span>
                </div>
                <span className="text-brand-primary text-xs font-bold">UPTIME: {uptime.toFixed(3)}%</span>
              </div>
              <div className="flex justify-between items-center text-slate-500">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_5px_#06b6d4]"></div>
                  <span className="text-slate-300 font-bold">Mikrotik_GW_04</span>
                </div>
                <span className="text-cyan-400 text-xs font-bold tracking-widest">SECURE_PIPE</span>
              </div>
            </div>

            {/* Scrolling Logs */}
            <div className="mt-6 h-16 overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-transparent to-slate-950/80 pointer-events-none z-10"></div>
              <motion.div 
                animate={{ y: [0, -100] }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="font-mono text-[9px] text-slate-400 space-y-1.5 p-2"
              >
                <div>[INFO] Cloudflare tunnel established...</div>
                <div>[DEBUG] Responding to ICMP request from 192.168.1.1</div>
                <div>[SEC] Zero-Trust policy synchronized</div>
                <div>[LOG] Azure Blob container mounted at /mnt/data</div>
                <div>[OK] Nginx service reload successful</div>
                <div>[SSL] Certificate renewed (90 days remaining)</div>
                <div>[OK] PHP 8.2-FPM node processing incoming requests</div>
                <div>[INFO] System heartbeat: PASS</div>
              </motion.div>
            </div>
          </div>
          
          {/* Terminal floating element */}
          <motion.div 
            className="absolute -bottom-6 -right-6 p-4 glass-card shadow-2xl border-brand-primary/40 max-w-[180px] bg-slate-950/90"
            animate={{ y: [0, -15, 0], x: [0, 5, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-2">
              <Terminal className="w-4 h-4 text-brand-primary" />
              <span className="font-mono text-[10px] font-bold text-white uppercase tracking-widest">Active_Tasks</span>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-[9px] font-mono mb-1">
                <span className="text-slate-600">Sync_DB</span>
                <span className="text-brand-primary">DONE</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full">
                <motion.div animate={{ width: [0, "100%", "100%"] }} transition={{ duration: 3, repeat: Infinity }} className="h-full bg-brand-primary"></motion.div>
              </div>
              
              <div className="flex justify-between items-center text-[9px] font-mono mb-1">
                <span className="text-slate-600">Patch_Kernel</span>
                <span className="text-cyan-400">72%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full">
                <motion.div animate={{ width: "72%" }} className="h-full bg-cyan-500"></motion.div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
