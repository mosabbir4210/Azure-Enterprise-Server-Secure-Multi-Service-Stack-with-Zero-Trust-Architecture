import React from 'react';
import Section from './Section';
import type { Certification } from '../types';
import { motion } from 'framer-motion';
import { Award, ExternalLink } from 'lucide-react';

interface CertificationsProps {
  certifications: Certification[];
}

const Certifications: React.FC<CertificationsProps> = ({ certifications }) => {
  return (
    <Section id="certifications" title="TRAINING_AND_CERTIFICATION">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {certifications.map((cert, idx) => (
          <motion.div 
            key={idx}
            className="glass-card flex flex-col group hover:border-brand-primary/40 transition-all"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ 
              duration: 0.5,
              delay: idx * 0.1,
              ease: [0.25, 1, 0.5, 1] // Custom ease for smoother finish
            }}
            viewport={{ once: true, margin: "-50px" }}
          >
            <div className="p-1 px-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
              <span className="tech-label text-slate-600">ID: CERT_{104 + idx}</span>
              <Award className="w-4 h-4 text-brand-primary opacity-50 group-hover:opacity-100 transition-opacity" />
            </div>
            
            <div className="p-6 flex-1">
              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-brand-primary transition-colors">{cert.title}</h3>
              <div className="flex items-center gap-3 mb-4">
                <span className="px-2 py-0.5 bg-slate-800 rounded text-[10px] font-mono text-slate-400 uppercase tracking-tighter">
                  {cert.provider}
                </span>
                {cert.duration && (
                  <span className="text-[10px] font-mono text-slate-500 italic">{cert.duration}</span>
                )}
              </div>
              <p className="text-sm text-slate-400 leading-relaxed font-sans">{cert.details}</p>
            </div>
            
            {cert.link && (
              <div className="px-6 py-4 bg-slate-900/50 border-t border-slate-800 flex justify-end">
                <a 
                  href={cert.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-brand-primary/10 border border-brand-primary/30 rounded-lg text-[10px] font-mono text-brand-primary uppercase tracking-widest hover:bg-brand-primary hover:text-slate-950 transition-all shadow-[0_0_15px_rgba(16,185,129,0.1)] hover:shadow-[0_0_20px_rgba(16,185,129,0.4)]"
                >
                  Verify_Status <ExternalLink size={12} />
                </a>
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Certifications;