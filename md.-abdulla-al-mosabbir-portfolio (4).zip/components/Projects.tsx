import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, Terminal, Github, X, Info, Box, Cpu, ChevronRight, ShieldCheck } from 'lucide-react';
import Section from './Section';
import type { Project } from '../types';

interface ProjectsProps {
  projects: Project[];
}

const Projects: React.FC<ProjectsProps> = ({ projects }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedProject(null);
    };

    if (selectedProject) {
      window.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
      // Wait for modal animation to settle before focusing
      const timer = setTimeout(() => {
        closeButtonRef.current?.focus();
      }, 300);
      return () => {
        clearTimeout(timer);
        window.removeEventListener('keydown', handleEscape);
        document.body.style.overflow = 'unset';
      };
    }
  }, [selectedProject]);

  return (
    <Section id="projects" title="PRODUCTION_LABS">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group relative bg-slate-900/50 border border-slate-800 p-6 rounded-xl hover:border-brand-primary/50 transition-all duration-300 overflow-hidden flex flex-col"
          >
            {/* Background decoration */}
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <Terminal size={80} />
            </div>

            <div className="relative z-10 flex flex-col h-full">
              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-brand-primary transition-colors flex items-center gap-2">
                <Box size={18} className="text-brand-primary" />
                {project.name}
              </h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed line-clamp-3">
                {project.description}
              </p>

              {/* Tags Area */}
              {project.tags && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, tIdx) => (
                    <span key={tIdx} className="px-2 py-0.5 text-[9px] font-mono bg-slate-800 text-slate-300 rounded border border-slate-700">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
              
              <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-800/50">
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-[10px] font-mono text-brand-primary flex items-center gap-1 hover:underline uppercase tracking-widest cursor-pointer text-left"
                    aria-label={`Open details for ${project.name}`}
                  >
                    <Info size={12} /> Inspect_Details
                  </button>
                  
                  {project.link ? (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={project.link}
                      className="text-[10px] font-mono text-slate-400 flex items-center gap-1 hover:text-white transition-colors uppercase tracking-widest"
                    >
                      Live <ExternalLink size={10} />
                    </a>
                  ) : (
                    <span className="text-[10px] font-mono text-slate-700 uppercase tracking-widest cursor-not-allowed">Internal_Only</span>
                  )}
                </div>

                {/* Highlighted GitHub Section */}
                <div className="flex items-center">
                  {project.github && project.github !== "Internal_Only" ? (
                    <motion.a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center gap-2 px-3 py-1.5 bg-brand-primary/10 border border-brand-primary/20 rounded-lg text-brand-primary hover:bg-brand-primary hover:text-slate-900 transition-all duration-300 text-[10px] font-bold uppercase tracking-wider shadow-lg shadow-brand-primary/5"
                    >
                      <Github size={12} /> Github Link
                    </motion.a>
                  ) : (
                    <span className="text-[10px] font-mono text-slate-600 italic">Private_Repo</span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Beautiful Modal System */}
      <AnimatePresence>
        {selectedProject && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            aria-describedby="modal-description"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-slate-950/90 backdrop-blur-md scanlines noise"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-3xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              {/* Terminal Header */}
              <div className="sticky top-0 z-20 bg-slate-800/90 backdrop-blur-sm px-4 py-3 border-b border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/50" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                    <div className="w-3 h-3 rounded-full bg-green-500/50" />
                  </div>
                  <span className="ml-2 text-xs font-mono text-slate-400">system_node:/{selectedProject.name.toLowerCase().replace(/\s+/g, '_').slice(0, 20)}...</span>
                </div>
                <button 
                  ref={closeButtonRef}
                  onClick={() => setSelectedProject(null)}
                  className="p-1 hover:bg-slate-700 rounded-md text-slate-400 hover:text-white transition-colors focus:ring-2 focus:ring-brand-primary outline-none"
                  aria-label="Close modal"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 md:p-10">
                <div className="flex items-start gap-4 mb-8">
                  <div className="p-3 bg-brand-primary/10 rounded-xl text-brand-primary">
                    <Cpu size={32} />
                  </div>
                  <div>
                    <h2 id="modal-title" className="text-2xl font-bold text-white mb-2">{selectedProject.name}</h2>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.tags?.map((tag, i) => (
                        <span key={i} className="text-[10px] font-mono text-brand-primary uppercase tracking-tighter border border-brand-primary/30 px-2 py-0.5 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* Visual Flow for Azure Project */}
                  {selectedProject.name.includes("Azure Enterprise Server") && (
                    <div className="bg-slate-950/50 border border-brand-primary/20 p-6 rounded-xl mb-6">
                      <p className="mb-4 text-brand-primary/60 tracking-widest text-[10px] uppercase font-bold">// Security Protocol Flow</p>
                      <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono">
                         <div className="flex flex-col items-center gap-2 p-3 bg-slate-900 border border-slate-800 rounded-lg w-full md:w-32 text-center">
                            <span className="text-slate-500">REQUEST</span>
                            <span className="text-white">User Traffic</span>
                         </div>
                         <ChevronRight className="rotate-90 md:rotate-0 text-brand-primary/40" />
                         <div className="flex flex-col items-center gap-2 p-3 bg-slate-900 border border-brand-primary/40 rounded-lg w-full md:w-40 text-center relative overflow-hidden group">
                            <div className="absolute inset-0 bg-brand-primary/5 group-hover:bg-brand-primary/10 transition-colors" />
                            <ShieldCheck className="text-brand-primary animate-pulse" size={16} />
                            <span className="text-brand-primary font-bold">Cloudflare Tunnel</span>
                            <span className="text-[10px] text-slate-500 uppercase tracking-tighter">Zero Trust Auth</span>
                         </div>
                         <ChevronRight className="rotate-90 md:rotate-0 text-brand-primary/40" />
                         <div className="flex flex-col items-center gap-2 p-3 bg-slate-900 border border-blue-500/40 rounded-lg w-full md:w-32 text-center">
                            <span className="text-blue-400 font-bold">Azure VM</span>
                            <span className="text-[10px] text-slate-500">CYBERPANEL</span>
                         </div>
                      </div>
                    </div>
                  )}

                  <div id="modal-description" className="bg-slate-950 border border-slate-800 p-6 rounded-lg font-mono text-sm leading-relaxed text-slate-300">
                    <p className="mb-4 text-brand-primary/60 tracking-widest text-[10px] uppercase">// Project Overview</p>
                    {selectedProject.description}
                  </div>

                  {selectedProject.link && (
                    <div className="mt-6">
                      <p className="mb-4 text-brand-primary/60 tracking-widest text-[10px] uppercase">// System Architecture Preview</p>
                      <div className="w-full aspect-video rounded-xl border border-slate-800 overflow-hidden bg-slate-950 relative group/iframe">
                        {/* Lazy Loading Placeholder */}
                        <div className="absolute inset-0 flex items-center justify-center bg-slate-900 z-0">
                          <div className="flex flex-col items-center gap-2">
                            <Box className="w-8 h-8 text-slate-700 animate-bounce" />
                            <span className="text-[10px] font-mono text-slate-700 uppercase">Loading_Node...</span>
                          </div>
                        </div>
                        <iframe 
                          src={selectedProject.link} 
                          className="w-full h-full border-none relative z-10"
                          title="Architecture Preview"
                          loading="lazy"
                        />
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {selectedProject.link && (
                      <motion.a 
                        href={selectedProject.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.02, y: -2 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center justify-center gap-2 p-4 bg-brand-primary text-slate-900 rounded-xl font-bold hover:bg-brand-primary/90 transition-colors shadow-lg shadow-brand-primary/20"
                      >
                        <ExternalLink size={20} /> VISIT_LIVE
                      </motion.a>
                    )}
                    {selectedProject.github && selectedProject.github !== "Internal_Only" && (
                      <motion.a 
                        href={selectedProject.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.02, y: -2 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center justify-center gap-2 p-4 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-700 transition-colors border border-slate-700"
                      >
                        <Github size={20} /> Github Link
                      </motion.a>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/30 px-8 py-4 border-t border-slate-800 flex justify-between items-center text-[10px] font-mono text-slate-500 uppercase tracking-[0.2em]">
                <span>Status: Deployed_Production</span>
                <span>Security: Cloudflare_Protected</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Section>
  );
};

export default Projects;