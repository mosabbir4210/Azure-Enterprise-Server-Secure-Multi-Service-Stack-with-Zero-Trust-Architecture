
import React from 'react';

interface FooterProps {
    name: string;
}

const Footer: React.FC<FooterProps> = ({ name }) => {
    const currentYear = new Date().getFullYear();
    return (
        <footer className="bg-bg-deep border-t border-slate-800 py-12">
            <div className="container mx-auto px-6 text-center">
                <div className="flex flex-col items-center gap-4">
                    <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full bg-brand-primary"></span>
                        <span className="tech-label">System Status: Nominal</span>
                    </div>
                    <p className="text-slate-500 font-mono text-[10px] uppercase tracking-[0.3em]">
                        &copy; {currentYear} {name} // All_Data_Secured
                    </p>
                    <div className="flex gap-4 text-[9px] font-mono text-slate-700">
                        <span>LATENCY: 24ms</span>
                        <span>|</span>
                        <span>SERVER: ASI_SE1</span>
                        <span>|</span>
                        <span>LOAD: 0.12</span>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
