import React from 'react';
import Section from './Section';
import type { Job } from '../types';
import { motion } from 'framer-motion';
import { Briefcase, ExternalLink } from 'lucide-react';

interface ExperienceProps {
  experience: Job[];
}

const Experience: React.FC<ExperienceProps> = ({ experience }) => {
  return (
    <Section id="experience" title="WORK_EXPERIENCE">
      <div className="relative pl-8 border-l border-slate-800 space-y-12">
        {experience.map((job, idx) => (
          <motion.div 
            key={idx}
            className="relative"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            viewport={{ once: true }}
          >
            {/* Timeline Dot */}
            <div className="absolute -left-[41px] top-0 w-6 h-6 rounded-full bg-bg-deep border-2 border-brand-primary flex items-center justify-center shadow-[0_0_10px_rgba(16,185,129,0.3)]">
              <Briefcase className="w-3 h-3 text-brand-primary" />
            </div>

            <div className="glass-card hover:border-brand-primary/30 transition-colors">
              <div className="p-1.5 px-4 bg-slate-950 border-b border-slate-800 flex flex-wrap justify-between items-center gap-4">
                <div className="flex items-center gap-3">
                  <span className="tech-label text-slate-500">Node: {idx + 1}</span>
                  <h3 className="text-sm font-mono font-bold text-white uppercase tracking-tight">{job.title}</h3>
                </div>
                <span className="font-mono text-[10px] text-brand-primary/70">{job.duration}</span>
              </div>
              
              <div className="p-6">
                <div className="mb-4">
                  <span className="text-xl font-bold text-white">{job.company}</span>
                </div>
                
                <ul className="space-y-3">
                  {job.responsibilities.map((resp, i) => (
                    <li key={i} className="flex gap-3 text-sm text-slate-400 group">
                      <span className="text-brand-primary font-mono select-none">::</span>
                      <span className="group-hover:text-slate-200 transition-colors">{resp}</span>
                    </li>
                  ))}
                </ul>

                {job.link && (
                  <div className="mt-6 pt-4 border-t border-slate-800">
                    <a 
                      href={job.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-xs font-mono text-brand-primary hover:text-white transition-colors group/link"
                    >
                      <span className="opacity-50 tracking-tighter">{"> FETCH_VERIFIED_CREDENTIAL"}</span>
                      <ExternalLink className="w-3 h-3 group-hover/link:translate-x-0.5 transition-transform" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
        
        {/* Terminal decorative end */}
        <div className="absolute -left-[9px] -bottom-2 w-4 h-4 bg-slate-800 rounded-sm transform rotate-45 border border-slate-700"></div>
      </div>
    </Section>
  );
};

export default Experience;