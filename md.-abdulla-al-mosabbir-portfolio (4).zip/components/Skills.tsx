import React from 'react';
import Section from './Section';
import type { SkillGroup } from '../types';
import { motion } from 'framer-motion';
import { Cloud, Network, Server } from 'lucide-react';

interface SkillsProps {
  skills: SkillGroup[];
}

const getIcon = (name: string) => {
  const n = name.toLowerCase();
  if (n.includes('cloud')) return <Cloud className="w-5 h-5" />;
  if (n.includes('networking')) return <Network className="w-5 h-5" />;
  return <Server className="w-5 h-5" />;
};

const Skills: React.FC<SkillsProps> = ({ skills }) => {
  return (
    <Section id="skills" title="SYSTEM_INVENTORY">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {skills.map((skillGroup, idx) => (
          <motion.div 
            key={idx} 
            className="glass-card p-6 hover:border-brand-primary/50 transition-colors group"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="text-brand-primary group-hover:scale-110 transition-transform">
                {getIcon(skillGroup.name)}
              </div>
              <h3 className="text-lg font-bold text-white uppercase tracking-tight">{skillGroup.name}</h3>
            </div>
            
            <div className="space-y-4">
              {skillGroup.items.map((item, i) => (
                <div key={i} className="flex flex-col gap-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-300 font-medium">{item.split('(')[0].trim()}</span>
                    {item.includes('(') && (
                      <span className="tech-label text-[8px] text-slate-500">
                        {item.match(/\(([^)]+)\)/)?.[1] || "STABLE"}
                      </span>
                    )}
                  </div>
                  <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-slate-700 group-hover:bg-brand-primary/50 transition-colors"
                      initial={{ width: 0 }}
                      whileInView={{ width: "100%" }}
                      transition={{ delay: 0.5 + (i * 0.1), duration: 1 }}
                      viewport={{ once: true }}
                    />
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 pt-6 border-t border-slate-800 flex justify-between items-center">
              <span className="tech-label text-slate-600">Status</span>
              <span className="text-[10px] font-mono text-brand-primary">READY.v1</span>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Skills;