import React from 'react';
import Section from './Section';
import type { EducationItem } from '../types';
import { motion } from 'framer-motion';
import { GraduationCap } from 'lucide-react';

interface EducationProps {
  education: EducationItem[];
}

const Education: React.FC<EducationProps> = ({ education }) => {
  return (
    <Section id="education" title="ACADEMIC_RECORDS">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {education.map((edu, idx) => (
          <motion.div 
            key={idx}
            className="glass-card p-6 border-l-4 border-l-brand-primary group transition-all"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            viewport={{ once: true }}
          >
            <div className="flex gap-4">
              <div className="mt-1 p-2 bg-brand-primary/10 rounded-lg text-brand-primary group-hover:bg-brand-primary group-hover:text-slate-950 transition-colors shrink-0">
                <GraduationCap size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-1 leading-tight">{edu.degree}</h3>
                <p className="text-brand-primary font-mono text-sm mb-3">{edu.institution}</p>
                <div className="flex items-center gap-4">
                  {edu.year && (
                    <div className="flex flex-col">
                      <span className="tech-label text-[8px]">Graduation</span>
                      <span className="text-xs text-slate-400 font-mono">{edu.year}</span>
                    </div>
                  )}
                  {edu.status && (
                    <div className="flex flex-col">
                      <span className="tech-label text-[8px]">Status</span>
                      <span className="text-xs text-emerald-400 font-mono italic animate-pulse">{edu.status}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Education;