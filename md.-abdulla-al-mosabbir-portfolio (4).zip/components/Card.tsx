
import React from "react";
import { motion } from "framer-motion";

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.95 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5 }}
    className={`bg-slate-800/50 p-8 rounded-2xl shadow-xl border border-slate-700 backdrop-blur-sm ${className}`}
  >
    {children}
  </motion.div>
);

export default Card;
