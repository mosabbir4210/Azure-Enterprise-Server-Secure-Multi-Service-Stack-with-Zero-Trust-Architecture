
import React, { useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";

interface SectionProps {
  id: string;
  title?: string;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ id, title, children }) => {
  const controls = useAnimation();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  const variants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  return (
    <motion.section
      id={id}
      ref={ref}
      variants={variants}
      initial="hidden"
      animate={controls}
      className="py-16 md:py-24"
    >
      <div className="container mx-auto px-6 max-w-5xl">
        {title && (
          <div className="flex flex-col items-center mb-16">
            <motion.div 
              initial={{ width: 0 }}
              animate={inView ? { width: "100%" } : {}}
              className="h-px bg-gradient-to-r from-transparent via-brand-primary/50 to-transparent mb-8"
            />
            <motion.h2
              className="text-3xl md:text-5xl font-black text-white text-center font-mono tracking-tighter"
              initial={{ y: -20, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.6 }}
            >
              <span className="text-brand-primary opacity-50 mr-2">::</span>
              {title}
              <span className="animate-pulse ml-1 text-brand-primary">_</span>
            </motion.h2>
          </div>
        )}
        {children}
      </div>
    </motion.section>
  );
};

export default Section;
