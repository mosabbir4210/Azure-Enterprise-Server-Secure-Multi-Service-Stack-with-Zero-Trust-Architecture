
import React from 'react';
import Section from './Section';

interface AboutProps {
    about: string;
}

const About: React.FC<AboutProps> = ({ about }) => {
    return (
        <Section id="about" title="MISSION_OBJECTIVE">
            <div className="glass-card relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-brand-primary"></div>
                <div className="p-8 md:p-12 relative">
                    <div className="flex items-center gap-2 mb-6">
                        <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest">Type: Core_Biography</span>
                        <span className="h-px flex-1 bg-slate-800"></span>
                    </div>
                    <p className="text-xl md:text-2xl leading-relaxed text-slate-300 font-light italic">
                        <span className="text-brand-primary not-italic font-bold mr-2">"</span>
                        {about}
                        <span className="text-brand-primary not-italic font-bold ml-2">"</span>
                    </p>
                    <div className="mt-8 flex justify-end">
                        <div className="text-right">
                            <span className="tech-label block">Signature</span>
                            <span className="font-mono text-white">MD. Abdulla Al Mosabbir</span>
                        </div>
                    </div>
                </div>
            </div>
        </Section>
    );
};

export default About;
