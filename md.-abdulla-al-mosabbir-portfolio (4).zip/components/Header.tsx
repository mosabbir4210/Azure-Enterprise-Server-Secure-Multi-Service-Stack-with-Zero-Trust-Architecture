
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Cpu } from "lucide-react";
import { navLinks } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      const headerHeight = 80;
      window.scrollTo({
        top: targetElement.offsetTop - headerHeight,
        behavior: "smooth"
      });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-bg-deep/80 backdrop-blur-md border-b border-border-subtle py-3" : "bg-transparent py-5"}`}>
      <nav className="container mx-auto px-6 flex justify-between items-center">
        <a href="#hero" className="flex items-center gap-2 group">
          <div className="p-1.5 bg-brand-primary/10 rounded-lg border border-brand-primary/20 group-hover:border-brand-primary/50 transition-colors">
            <Cpu className="w-6 h-6 text-brand-primary" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold text-white tracking-tight leading-none uppercase">Mosabbir</span>
            <span className="tech-label text-[8px]">System Engineer</span>
          </div>
        </a>
        
        <div className="md:hidden">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 text-slate-400 hover:text-white transition-colors"
            aria-label="Toggle Menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        <ul className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="font-mono text-[11px] uppercase tracking-widest text-slate-400 hover:text-brand-primary transition-colors py-2 relative group"
              >
                {link.text}
                <span className="absolute bottom-0 left-0 w-0 h-px bg-brand-primary group-hover:w-full transition-all duration-300"></span>
              </a>
            </li>
          ))}
          <li>
            <a 
              href="#contact" 
              className="px-4 py-2 bg-brand-primary/10 border border-brand-primary/30 rounded-md font-mono text-[11px] uppercase tracking-widest text-brand-primary hover:bg-brand-primary hover:text-white transition-all duration-300"
            >
              Contact_Sys
            </a>
          </li>
        </ul>
      </nav>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 w-full bg-bg-deep border-b border-border-subtle shadow-2xl py-8 px-6"
          >
            <ul className="flex flex-col gap-6">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="font-mono text-sm uppercase tracking-widest text-slate-400 hover:text-brand-primary block"
                  >
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
