
import React from 'react';
import Section from './Section';
import type { ContactDetails } from '../types';
import { Mail, Phone, MapPin, Linkedin, Github, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

interface ContactProps {
  contact: ContactDetails;
}

const Contact: React.FC<ContactProps> = ({ contact }) => {
  return (
    <Section id="contact" title="INITIALIZE_CONNECTION">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="space-y-6"
        >
          <h3 className="text-2xl font-bold text-white mb-6">Let's build something robust.</h3>
          <p className="text-slate-400 max-w-md">
            I'm always open to discussing new infrastructure projects, cloud migrations, or system audits. Feel free to reach out via any of the channels below.
          </p>
          
          <div className="space-y-4 pt-4">
            <div className="flex items-center gap-4 group">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-brand-primary group-hover:border-brand-primary/50 transition-colors">
                <Mail size={20} />
              </div>
              <div>
                <span className="tech-label text-[8px]">Email</span>
                <p className="text-white font-mono text-sm">{contact.email}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 group">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-brand-primary group-hover:border-brand-primary/50 transition-colors">
                <Phone size={20} />
              </div>
              <div>
                <span className="tech-label text-[8px]">Phone</span>
                <p className="text-white font-mono text-sm">{contact.phone}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 group">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-brand-primary group-hover:border-brand-primary/50 transition-colors">
                <MapPin size={20} />
              </div>
              <div>
                <span className="tech-label text-[8px]">Location</span>
                <p className="text-white font-mono text-sm">{contact.address}</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="glass-card p-8 flex flex-col items-center justify-center text-center"
        >
          <div className="w-16 h-16 bg-brand-primary/10 rounded-full flex items-center justify-center text-brand-primary mb-6">
            <Activity size={32} className="animate-pulse" />
          </div>
          <h4 className="text-xl font-bold text-white mb-2 uppercase tracking-tight">System_Ready</h4>
          <p className="text-sm text-slate-500 mb-8 max-w-[200px]">
            Response time: {"< "} 24 hours
          </p>
          
          <div className="flex gap-4">
            <a 
              href={contact.linkedin} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 hover:text-brand-primary hover:border-brand-primary/50 transition-all hover:-translate-y-1"
            >
              <Linkedin size={24} />
            </a>
            <a 
              href={contact.github} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 hover:text-brand-primary hover:border-brand-primary/50 transition-all hover:-translate-y-1"
            >
              <Github size={24} />
            </a>
          </div>
          
          <a 
            href={`mailto:${contact.email}`}
            className="mt-8 w-full py-4 bg-brand-primary text-slate-950 font-bold rounded-lg uppercase tracking-widest text-xs hover:shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all"
          >
            Send_Message
          </a>
        </motion.div>
      </div>
    </Section>
  );
};

export default Contact;
