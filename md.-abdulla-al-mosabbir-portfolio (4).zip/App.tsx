
import React from "react";
import { Helmet, HelmetProvider } from "react-helmet-async";
import { portfolioData } from "./constants";
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Experience from "./components/Experience";
import Education from "./components/Education";
import Certifications from "./components/Certifications";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

const App: React.FC = () => {
  return (
    <HelmetProvider>
      <div className="bg-slate-900 text-gray-200 font-sans leading-relaxed selection:bg-emerald-500 selection:text-white">
        <Helmet>
          <title>{`${portfolioData.name} | ${portfolioData.title}`}</title>
          <meta
            name="description"
            content={`Professional Portfolio of ${portfolioData.name} - ${portfolioData.title}. Expert in Cloud Infrastructure, System Engineering, and Enterprise Networking (Azure, Cisco, Linux).`}
          />
          <meta 
            name="keywords" 
            content="System Engineer, Cloud Infrastructure, Azure, DevOps, Networking, Cisco, Mikrotik, Linux Administrator, IT Infrastructure, Cybersecurity, Server Deployment" 
          />
          <meta property="og:title" content={`${portfolioData.name} | ${portfolioData.title}`} />
          <meta property="og:description" content={portfolioData.tagline} />
          <meta name="author" content={portfolioData.name} />
        </Helmet>

        <Header />
        <main className="pt-20">
          <Hero data={{ name: portfolioData.name, title: portfolioData.title, tagline: portfolioData.tagline }} />
          <About about={portfolioData.about} />
          <Skills skills={portfolioData.skills} />
          <Experience experience={portfolioData.experience} />
          <Education education={portfolioData.education} />
          <Certifications certifications={portfolioData.certifications} />
          <Projects projects={portfolioData.projects} />
          <Contact contact={portfolioData.contact} />
        </main>
        <Footer name={portfolioData.name} />
      </div>
    </HelmetProvider>
  );
};

export default App;
