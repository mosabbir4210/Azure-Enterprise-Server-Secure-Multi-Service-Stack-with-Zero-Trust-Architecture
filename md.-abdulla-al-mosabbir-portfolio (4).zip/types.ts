
export interface SkillGroup {
  name: string;
  items: string[];
}

export interface Job {
  title: string;
  company: string;
  duration: string;
  responsibilities: string[];
  link?: string;
}

export interface EducationItem {
  degree: string;
  institution: string;
  year?: string;
  status?: string;
}

export interface Certification {
  title: string;
  provider?: string;
  duration?: string;
  details: string;
  link?: string;
}

export interface Project {
  name:string;
  description: string;
  link?: string;
  github?: string;
  tags?: string[];
}

export interface ContactDetails {
  email: string;
  phone: string;
  address: string;
  linkedin: string;
  github: string;
}

export interface PortfolioData {
  name: string;
  title: string;
  tagline: string;
  about: string;
  skills: SkillGroup[];
  experience: Job[];
  education: EducationItem[];
  certifications: Certification[];
  projects: Project[];
  contact: ContactDetails;
}

export interface NavLink {
  href: string;
  text: string;
}
